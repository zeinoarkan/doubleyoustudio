<!DOCTYPE html>
<html>
<head>
    <title>Login Admin</title>
</head>
<body>

<h2>Login Admin</h2>

@if (session('error'))
    <p style="color:red">{{ session('error') }}</p>
@endif

<form method="POST" action="/admin/login">
    @csrf

    <div>
        <label>Username</label><br>
        <input type="text" name="username">
    </div>

    <div>
        <label>Password</label><br>
        <input type="password" name="password">
    </div>

    <button type="submit">Login</button>
</form>

</body>
</html>
