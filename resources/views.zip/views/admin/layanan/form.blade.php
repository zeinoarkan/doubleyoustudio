<!DOCTYPE html>
<html>
<head>
    <title>Form Layanan</title>
</head>
<body>

<h2>{{ isset($layanan) ? 'Edit' : 'Tambah' }} Layanan</h2>

<form method="POST"
      action="{{ isset($layanan)
                ? route('admin.layanan.update', $layanan->id_layanan)
                : route('admin.layanan.store') }}">
    @csrf

    <div>
        <label>Nama Layanan</label><br>
        <input type="text" name="nama_layanan"
            value="{{ $layanan->nama_layanan ?? '' }}">
    </div>

    <div>
        <label>Harga Weekday</label><br>
        <input type="number" name="harga_weekday"
            value="{{ $layanan->harga_weekday ?? '' }}">
    </div>

    <div>
        <label>Harga Weekend</label><br>
        <input type="number" name="harga_weekend"
            value="{{ $layanan->harga_weekend ?? '' }}">
    </div>

    <div>
        <label>Durasi (menit)</label><br>
        <input type="number" name="durasi_menit"
            value="{{ $layanan->durasi_menit ?? '' }}">
    </div>

    <div>
        <label>Deskripsi</label><br>
        <textarea name="deskripsi">{{ $layanan->deskripsi ?? '' }}</textarea>
    </div>

</form>

<br>
<a href="{{ route('admin.layanan') }}">← Kembali</a>

</body>
</html>
