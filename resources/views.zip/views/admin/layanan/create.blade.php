@extends('layouts.admin')

@section('content')
<h1 class="text-2xl font-bold mb-6">Tambah Layanan</h1>

<form method="POST" action="{{ route('admin.layanan.store') }}"
      class="bg-white p-6 rounded shadow max-w-xl space-y-4">
    @csrf

    <div>
        <label class="block text-sm font-medium">Nama Layanan</label>
        <input type="text" name="nama_layanan"
               class="w-full border rounded px-3 py-2">
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium">Harga Weekday</label>
            <input type="number" name="harga_weekday"
                   class="w-full border rounded px-3 py-2">
        </div>

        <div>
            <label class="block text-sm font-medium">Harga Weekend</label>
            <input type="number" name="harga_weekend"
                   class="w-full border rounded px-3 py-2">
        </div>
    </div>

    <div>
        <label class="block text-sm font-medium">Durasi (menit)</label>
        <input type="number" name="durasi_menit"
               class="w-full border rounded px-3 py-2">
    </div>

    <div>
        <label class="block text-sm font-medium">Deskripsi</label>
        <textarea name="deskripsi"
                  class="w-full border rounded px-3 py-2"></textarea>
    </div>

    <div class="flex justify-end gap-3 mt-6">
    <a href="{{ route('admin.layanan') }}"
       class="px-6 py-2 border rounded">
        Batal
    </a>

    <button type="submit"
        class="bg-[#1e1b4b] text-white px-6 py-2 rounded">
        Simpan
    </button>
</div>

</form>
@endsection
