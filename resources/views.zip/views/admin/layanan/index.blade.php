@extends('layouts.admin')

@section('content')
<div class="flex justify-between items-center mb-6">
    <h1 class="text-2xl font-bold">Layanan</h1>

    <a href="{{ route('admin.layanan.create') }}"
       class="bg-[#1e1b4b] text-white px-4 py-2 rounded hover:bg-indigo-900">
        + Tambah Layanan
    </a>
</div>

<div class="bg-white rounded shadow overflow-x-auto">
    <table class="w-full text-sm">
        <thead class="bg-gray-100">
            <tr>
                <th class="px-4 py-3 text-left">Nama</th>
                <th class="px-4 py-3">Weekday</th>
                <th class="px-4 py-3">Weekend</th>
                <th class="px-4 py-3">Durasi</th>
                <th class="px-4 py-3">Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($layanan as $item)
            <tr class="border-t">
                <td class="px-4 py-3">{{ $item->nama_layanan }}</td>
                <td class="px-4 py-3">Rp {{ number_format($item->harga_weekday) }}</td>
                <td class="px-4 py-3">Rp {{ number_format($item->harga_weekend) }}</td>
                <td class="px-4 py-3">{{ $item->durasi_menit }} menit</td>
                <td class="px-4 py-3 space-x-2">
                    <a href="{{ route('admin.layanan.edit', $item->id_layanan) }}"
                       class="text-blue-600 hover:underline">Edit</a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
