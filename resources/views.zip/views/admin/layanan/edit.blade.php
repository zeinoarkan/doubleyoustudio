@extends('admin.layouts.app')

@section('content')

<h1>Edit Layanan</h1>

<div class="card">
    <form method="POST" action="{{ route('admin.layanan.update', $layanan->id_layanan) }}">
        @csrf

        <p>
            <label>Nama Layanan</label><br>
            <input type="text" name="nama_layanan" value="{{ $layanan->nama_layanan }}">
        </p>

        <p>
            <label>Harga Weekday</label><br>
            <input type="number" name="harga_weekday" value="{{ $layanan->harga_weekday }}">
        </p>

        <p>
            <label>Harga Weekend</label><br>
            <input type="number" name="harga_weekend" value="{{ $layanan->harga_weekend }}">
        </p>

        <p>
            <label>Durasi (menit)</label><br>
            <input type="number" name="durasi_menit" value="{{ $layanan->durasi_menit }}">
        </p>

        <p>
            <label>Deskripsi</label><br>
            <textarea name="deskripsi">{{ $layanan->deskripsi }}</textarea>
        </p>

        <button type="submit">Update</button>
    </form>
</div>

@endsection
