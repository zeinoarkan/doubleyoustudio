@extends('admin.layouts.app')

@section('content')

<h1>Data Pesanan</h1>

<div class="card">

    {{-- <a href="{{ route('admin.pesanan.export.excel') }}">Export Excel</a> |
    <a href="{{ route('admin.pesanan.export.pdf') }}">Export PDF</a> --}}

    <br><br>

    <table border="1" cellpadding="10" width="100%">
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Layanan</th>
            <th>No WA</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>

        @foreach ($pesanan as $item)
        <tr>
            <td>{{ $loop->iteration }}</td>
            <td>{{ $item->nama_pelanggan }}</td>
            <td>{{ $item->layanan->nama_layanan ?? '-' }}</td>
            <td>{{ $item->no_wa }}</td>
            <td>{{ $item->status_pemesanan }}</td>
            <td>
                <a href="{{ route('admin.pesanan.show', $item->id_pemesanan) }}">Detail</a> |
                <a href="{{ route('admin.pesanan.delete', $item->id_pemesanan) }}"
                   onclick="return confirm('Hapus pesanan?')">Hapus</a>
            </td>
        </tr>
        @endforeach
    </table>

</div>

@endsection
