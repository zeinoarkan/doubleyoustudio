@extends('layouts.app')

@section('content')
    <section class="bg-white min-h-screen flex flex-col font-sans overflow-x-hidden">

        {{-- Header: Dibuat compact agar langsung terlihat di layar HP --}}
        <div class="w-full pt-12 md:pt-16 px-6 text-center">
            <h1 class="text-5xl md:text-6xl text-gray-400 font-light">
                <span class="opacity-40">_</span>Contact <span class="text-amber-600 font-medium font-serif">Double You.</span>
            </h1>
            <p class="mt-3 md:mt-6 text-sm md:text-xl text-gray-400 max-w-2xl mx-auto px-4">
                Kalau kalian bingung, bisa konsultasi sama kita yaa!
            </p>
        </div>


        {{-- Grid Section: 2 Kolom di mobile agar tidak memanjang ke bawah --}}
        <div class="flex-grow flex items-start justify-center pt-10 md:pt-32 pb-10">
            <div class="max-w-7xl mx-auto px-4 grid grid-cols-2 lg:grid-cols-4 gap-y-12 gap-x-4 md:gap-x-12 text-center w-full">

                <div class="flex flex-col items-center group">
                    <div class="mb-4 p-3 bg-gray-50 rounded-2xl md:bg-transparent md:p-0 transition-all">
                        <svg class="w-10 h-10 md:w-16 md:h-16 text-black stroke-[1.2px]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    </div>
                    <h3 class="text-xs md:text-xl font-semibold text-black mb-1">Open Hours:</h3>
                    <p class="text-[10px] md:text-sm text-blue-900 opacity-70 leading-tight">Everyday depends<br>on the outlet</p>
                    <p class="text-[10px] md:text-sm font-semibold text-blue-500 mt-1 uppercase">11:00 – 21:00</p>
                </div>

                <div class="flex flex-col items-center">
                    <div class="mb-4 p-3 bg-gray-50 rounded-2xl md:bg-transparent md:p-0">
                        <svg class="w-10 h-10 md:w-16 md:h-16 text-black stroke-[1.2px]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-5">Send Us A Message</h3>
                    <a href="#" class="w-full max-w-[110px] md:max-w-[200px] py-2 border border-green-500 text-green-600 rounded-full flex items-center justify-center gap-1 hover:bg-green-50 transition-all text-[10px] md:text-sm font-bold shadow-sm">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" class="w-3 h-3 md:w-4 md:h-4" alt="WA">
                        Chat Us
                    </a>
                </div>

                <div class="flex flex-col items-center">
                    <div class="mb-4 p-3 bg-gray-50 rounded-2xl md:bg-transparent md:p-0">
                        <svg class="w-10 h-10 md:w-16 md:h-16 text-black stroke-[1.2px]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-5">Ready On Google Maps</h3>
                    <a href="#" class="w-full max-w-[110px] md:max-w-[200px] py-2 border border-blue-600 text-blue-600 rounded-full flex items-center justify-center hover:bg-blue-50 transition-all text-[10px] md:text-sm font-bold shadow-sm">
                        Maps
                    </a>
                </div>

                <div class="flex flex-col items-center">
                    <div class="mb-4 p-3 bg-gray-50 rounded-2xl md:bg-transparent md:p-0">
                        <svg class="w-10 h-10 md:w-16 md:h-16 text-black stroke-[1.2px]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>
                    </div>
                    <h3 class="text-xs md:text-xl font-semibold text-black mb-2">Partnership</h3>
                    <a href="mailto:doubleyou@mail.com" class="text-[10px] md:text-sm text-blue-500 font-medium hover:underline break-all px-2">
                        Email Us
                    </a>
                </div>

            </div>
        </div>
    </section>
@endsection
