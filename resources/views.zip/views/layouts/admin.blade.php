<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin - Double You Studio</title>
    @vite('resources/css/app.css')
</head>
<body class="bg-gray-100 text-gray-800">

<div class="flex min-h-screen">

    {{-- SIDEBAR --}}
    <aside class="w-64 bg-[#1e1b4b] text-white flex flex-col">
        <div class="p-6 font-bold text-xl border-b border-white/20">
            Admin Panel
        </div>

        <nav class="flex-1 p-4 space-y-2">
            <a href="{{ route('admin.dashboard') }}"
               class="block px-4 py-2 rounded hover:bg-white/10">
                Dashboard
            </a>

            <a href="{{ route('admin.layanan') }}"
               class="block px-4 py-2 rounded hover:bg-white/10">
                Layanan
            </a>

            <a href="{{ route('admin.pesanan') }}"
               class="block px-4 py-2 rounded hover:bg-white/10">
                Pesanan
            </a>
        </nav>

        <div class="p-4 border-t border-white/20">
            <a href="{{ route('admin.logout') }}"
               class="block text-red-300 hover:text-red-400">
                Logout
            </a>
        </div>
    </aside>

    {{-- CONTENT --}}
    <main class="flex-1 p-8">
        @yield('content')
    </main>

</div>

</body>
</html>
