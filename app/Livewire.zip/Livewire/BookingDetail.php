<?php

namespace App\Livewire;

use Livewire\Component;
use App\Models\JadwalStudio;
use App\Models\Layanan;
use App\Models\Pemesanan;
use Illuminate\Support\Facades\DB;

class BookingDetail extends Component
{
    public $jadwalId, $paketId;
    public $jadwal, $paket;
    public $nama_pelanggan, $no_wa;

    public function mount($jadwal, $paket)
    {
        $this->jadwalId = $jadwal;
        $this->paketId = $paket;

        // Ambil data untuk ditampilkan di ringkasan
        $this->jadwal = JadwalStudio::findOrFail($jadwal);
        $this->paket = Layanan::where('id_layanan', $paket)->first();
    }

    public $jumlah_orang = 0; // Default 0 orang tambahan
    public function confirmBooking()
    {
        $this->validate([
            'nama_pelanggan' => 'required|min:3',
            'no_wa' => 'required|digits_between:10,15',
            'jumlah_orang' => 'required|integer',
        ]);

        // 1. Hitung Total Harga
        $total_harga = $this->paket->harga + ($this->jumlah_orang * 30000);

        try {
            DB::beginTransaction();

            // 2. Cari atau Buat Pelanggan (karena tabel terpisah)
            $pelanggan = \App\Models\Pelanggan::updateOrCreate(
                ['whatsapp' => $this->no_wa],
                ['nama' => $this->nama_pelanggan]
            );

            // 3. Simpan ke Tabel Pemesanan (Gunakan kolom asli DB Anda)
            $pemesanan = Pemesanan::create([
                'id_pelanggan' => $pelanggan->id_pelanggan,
                'id_layanan' => $this->paketId,
                'id_jadwal' => $this->jadwalId,
                'jumlah_customer' => $this->jumlah_orang, // Nama kolom sesuai DB
                'total_harga' => $total_harga,
                'status_pemesanan' => 'pending',          // Nama kolom sesuai DB
                'tanggal_pesan' => now(),
            ]);

            // 4. Konfigurasi Midtrans
            \Midtrans\Config::$serverKey = config('services.midtrans.serverKey');
            \Midtrans\Config::$isProduction = false;
            \Midtrans\Config::$isSanitized = true;
            \Midtrans\Config::$is3ds = true;

            $params = [
                'transaction_details' => [
                    'order_id' => 'INV-' . $pemesanan->id_pemesanan . '-' . time(),
                    'gross_amount' => (int) $total_harga,
                ],
                'customer_details' => [
                    'first_name' => $this->nama_pelanggan,
                    'phone' => $this->no_wa,
                ],
            ];

            $snapToken = \Midtrans\Snap::getSnapToken($params);

            DB::commit();

            // Kirim token ke view
            $this->dispatch('pay-with-midtrans', snapToken: $snapToken);

        } catch (\Exception $e) {
            DB::rollBack();
            dd($e->getMessage()); // Ini akan memaksa layar menampilkan error jika PHP gagal
        }

    }

    public function render()
    {
        return view('livewire.booking-detail')->layout('layouts.app');
    }
}
