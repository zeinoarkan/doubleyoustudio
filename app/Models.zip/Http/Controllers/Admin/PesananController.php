<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Pemesanan;

class PesananController extends Controller
{
    public function index()
    {
        $pesanans = Pemesanan::with('layanan')
            ->orderBy('tanggal_pesan', 'desc')
            ->get();

        return view('admin.pesanan.index', compact('pesanans'));
    }

    public function updateStatus($id)
    {
        $pesanan = Pemesanan::findOrFail($id);

        $pesanan->status_pemesanan =
            $pesanan->status_pemesanan === 'pending'
                ? 'lunas'
                : 'pending';

        $pesanan->save();

        return back()->with('success', 'Status pesanan diperbarui');
    }
}
