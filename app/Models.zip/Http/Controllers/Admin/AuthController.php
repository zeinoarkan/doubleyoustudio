<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;

class AuthController extends Controller
{
    public function showLogin()
    {
        return view('admin.login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);

        $admin = Admin::where('username', $request->username)
                      ->where('password', $request->password)
                      ->first();

        if (!$admin) {
            return back()->with('error', 'Username atau password salah');
        }

        session([
            'admin_logged_in' => true,
            'admin_id' => $admin->id_admin,
            'admin_username' => $admin->username,
        ]);

        return redirect()->route('admin.dashboard');
    }

    public function logout()
    {
        session()->flush();
        return redirect()->route('admin.login');
    }
}
