<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Layanan;

class LayananController extends Controller
{
    public function index()
    {
        $layanan = Layanan::all();
        return view('admin.layanan.index', compact('layanan'));
    }

    public function create()
    {
        return view('admin.layanan.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_layanan' => 'required',
            'harga' => 'required|numeric',
        ]);

    Layanan::create([
        'id_admin' => session('admin_id'),
        'nama_layanan' => $request->nama_layanan,
        'harga_weekday' => $request->harga_weekday,
        'harga_weekend' => $request->harga_weekend,
        'durasi_menit' => $request->durasi_menit,
        'deskripsi' => $request->deskripsi,
    ]);


        return redirect()->route('admin.layanan');
    }

    public function edit($id)
    {
        $layanan = Layanan::findOrFail($id);
        return view('admin.layanan.form', compact('layanan'));
    }

    public function update(Request $request, $id)
    {
        $layanan = Layanan::findOrFail($id);

    $layanan->update([
        'nama_layanan' => $request->nama_layanan,
        'harga_weekday' => $request->harga_weekday,
        'harga_weekend' => $request->harga_weekend,
        'durasi_menit' => $request->durasi_menit,
        'deskripsi' => $request->deskripsi,
    ]);


        return redirect()->route('admin.layanan');
    }

    public function destroy($id)
    {
        Layanan::findOrFail($id)->delete();
        return redirect()->route('admin.layanan');
    }
}
